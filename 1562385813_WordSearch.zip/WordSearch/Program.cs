﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordSearch
{
    class Program
    {
        static void Main(string[] args)
        {
            string sentienel = "";
            while (sentienel != "end")
            {
                string[] sentence = GetArray();
                Choice(sentence);
                Console.WriteLine("");
                Console.WriteLine("Would you Like to continue? type end to stop");
                sentienel = Console.ReadLine().ToLower();
            }
            Console.ReadKey();
            
        }
        public static void Choice(string[]sentence)
        {
            Console.WriteLine("Type Easy or Hard");
            string difficulty = Console.ReadLine().ToLower();
            //print the number of times the word appears
            if (difficulty == "easy")
            {
                Easy(sentence);
            }
            else if (difficulty == "hard")
            {
                Hard(sentence);
            }
        }
        public static string[] GetArray()
        {
            //Get The sentence and store it in an array
            Console.WriteLine("Enter Sentence: (one space please)");
            string sentence = Console.ReadLine().ToLower();
            string[] wordArray = sentence.Split(' ');
            return wordArray;
        }
        public static void Easy(string[] sentence)
        {
            //get word
            Console.WriteLine("Which word would you like to check for:");
            string word = Console.ReadLine().ToLower();
            //store string array in list
            List<string> check = sentence.ToList();
            //find all string elements that contain word
            List<string> findAll = check.FindAll(m => m.Contains(word));
            //print the count of the find all string and the word
            Console.WriteLine("Word {0} occurs {1} times", word, findAll.Count());
        }
        public static void Hard(string[] sentence)
        {
            //Make a list to store no duplicates
            List<string> NoDuplicates=new List<string>();
            //make an array to store the count of words
            List<int> count = new List<int>();
            //initialize an increment variable
            int x = 0;
            //place the string array to list
            List<string> check = sentence.ToList();
            //for each word in the list
            foreach(string word in check)
            {
                //store the count of the number  of times the word appears in the array
                int countWords = check.FindAll(m => m.Contains(word)).Count();
                //if the count is greater than or equal to one
                if(countWords >= 1)
                {
                // check if the array to store non duplicates contains the word already
                  bool contains=NoDuplicates.Contains(word);
                   //if it does skip over the word
                    if (contains)
                    {
                        //skip over the duplicate word
                    }
                    else
                    {
                        //otherwise add the word and store the count into the count array
                        NoDuplicates.Add(word);
                        count.Add(countWords);
                        //increment the count array
                        x++;
                    }
                }
            }
            int displayCount = 0;
            //for each word in the no duplicates array
            foreach(string word in NoDuplicates)
            {
                //display the word and number of times it appears in the word
                Console.WriteLine("{0} appears in the sentence {1} times", word, count[displayCount]);
                displayCount++;
            }
        }

    }
}
